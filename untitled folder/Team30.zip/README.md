Commands :
To compile: erlc Team30
To run: erl -noshell -s Team30 start test4.txt -s init stop

NOTE: for input it assumes the weights to be in non-decreasing, and rho < 0.25 ( conditions for the algorithm )
